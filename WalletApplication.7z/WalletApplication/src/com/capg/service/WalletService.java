package com.capg.service;

import com.capg.Model.User;
import com.capg.dao.UserDAO;
import com.capg.dao.UserDAOInterface;


public class WalletService implements  UserDAOInterface{
	public static String contactnovalidator ="[1-9]{1}[0-9]{9}"; //accepts 10 digits number
	public static String namevalidator = "[A-Z]*[a-z]*";//((\\s)))+[A-Z]*[a-z]*$     use the commented regex function for full name
	public static boolean stringValidator(String data,String pattern) {
		return data.matches(pattern); //matches input data with pattern 
	}
	
	
	static UserDAOInterface dao = new UserDAO();
	@Override
	public boolean createNewUser(User u) {
		// TODO Auto-generated method stub
		boolean result = dao.createNewUser(u);
		return result;
	}
	
	
	@Override
	public void getAccDetails(long accNumber) {
		// TODO Auto-generated method stub
		dao.getAccDetails(accNumber);
	}

	@Override
	public void depositMoney(long accnotemp, double balance1) {
		// TODO Auto-generated method stub
		dao.depositMoney(accnotemp, balance1);
	}

	@Override
	public void withdrawMoney(long accnotemp3, double balance2) {
		// TODO Auto-generated method stub
		dao.withdrawMoney(accnotemp3, balance2);
	}

	@Override
	public void printTransactions() {
		// TODO Auto-generated method stub
		dao.printTransactions();
	}

	

	@Override
	public void transferMoney(long accnotemp2, long accnotemp4, double balance3) {
		// TODO Auto-generated method stub
		dao.transferMoney(accnotemp2, accnotemp4, balance3);
	}

	
}
