package com.capg.Main;

import java.util.Scanner;

import com.capg.Model.User;
import com.capg.dao.UserDAOInterface;
import com.capg.service.WalletService;

public class Main {
	public static void main(String[] args){

		char choice;
		Scanner sc=new Scanner(System.in);
		UserDAOInterface service=new WalletService();
		System.out.println("                               Bank Wallet Application\n");
		do {
		System.out.println("Select your choice:\n");
		System.out.println("1: Create new account \n2: Show Account Balance \n3: Deposit \n4: Withdraw \n5: Fund Transfer \n6: Print Transaction \n7: Exit");
		
		int choise=sc.nextInt();
		sc.nextLine();
		switch(choise) {
		case 1:
		    User u = new User();
			System.out.println("Enter your name: ");
			String name=sc.nextLine();
			
			if(WalletService.stringValidator(name, WalletService.namevalidator)) {
			u.setName(name);
			}
			else {
				System.out.println("Invalid name");
				break;
			}
				System.out.println("Enter contact number: ");
			long phoneNumber=sc.nextLong();
			String s1=Long.toString(phoneNumber);
			if(WalletService.stringValidator(s1, WalletService.contactnovalidator)) {
				u.setPhoneNumber(phoneNumber);
				}
				else {
					System.out.println("Invalid phone number");
					break;
				}
			System.out.println("Enter balance amount: ");
			double balance=sc.nextDouble();
			u.setBalance(balance);
			long accNumber=1010101010l+phoneNumber;
			u.setAccNumber(accNumber);
			if(service.createNewUser(u)==true) {
				System.out.println("Account has created successfully.");
			}
			System.out.println("Generated account number: "+accNumber);
			break;
		case 2:
			System.out.println("Enter the account number of customer: ");
			long accNum=sc.nextLong();
			service.getAccDetails(accNum);
			break;
		case 3:
			System.out.println("Enter account number to be deposited in: ");
			long accnotemp=sc.nextLong();
			System.out.println("Enter deposit amount: ");
			double balance1=sc.nextDouble();
			service.depositMoney(accnotemp,balance1);
			System.out.println(balance1+ " Deposited");
			break;
		case 4:
			System.out.println("Enter account number to be withdrawn from: ");
			long accnotemp3=sc.nextLong();
			System.out.println("Enter amount to be withdrawn: ");
			double balance2=sc.nextDouble();
			service.withdrawMoney(accnotemp3,balance2);
			System.out.println(balance2+ " withdrawn");
			break;
		case 5:
			System.out.println("Enter account in which amount is to be transferred: ");
			long accnotemp2=sc.nextLong();
			System.out.println("Enter account to be transferred from: ");
			long accnotemp4=sc.nextLong();
			System.out.println("Enter the amount to be transferred: ");
			double balance3=sc.nextDouble();
			service.transferMoney(accnotemp2,accnotemp4,balance3);
			System.out.println(balance3+" transferred to "+accnotemp2);
			break;
		case 6:
			service.printTransactions();
			break;
		case 7:
			System.out.println("Exiting....");
			System.exit(0);
		}
		System.out.println("do you want to continue (y/n):");
		choice=sc.next().charAt(0);
		}while(choice != 'n');
		sc.close();
		}
}





//package com.capg.Main;
//
////Starter class to take input and show output
//
//import java.io.IOException;
//import java.util.Scanner;
//
//import com.capg.dao.DAOInterface;
//import com.capg.model.Customer;
//import com.capg.service.*;
//public class Main {
//public static void main(String[] args){
//
//	char choice;
//	Scanner sc=new Scanner(System.in);
//	DAOInterface serviceC=new WalletService();
//	System.out.println(" Bank Wallet Application ");
//	do {
//	System.out.println("Select your choice:");
//	System.out.println("1: Create account \n 2: Show Balance \n 3: Deposit \n 4: Withdraw \n 5: Fund Transfer \n 6: Print Transaction \n 7: Exit");
//	
//	int choise=sc.nextInt();
//	sc.nextLine();
//	switch(choise) {
//	case 1:
//	    Customer c = new Customer();
//		System.out.println("Enter Name: ");
//		String name=sc.nextLine();
//		
//		if(WalletService.stringValidator(name, WalletService.namevalidator)) {
//		c.setName(name);
//		}
//		else {
//			System.out.println("Invalid name");
//			break;
//		}
//			System.out.println("Enter phone number: ");
//		long phoneNo=sc.nextLong();
//		String s1=Long.toString(phoneNo);
//		if(WalletService.stringValidator(s1, WalletService.mobilenovalidator)) {
//			c.setPhoneNo(phoneNo);
//			}
//			else {
//				System.out.println("Invalid phone number");
//				break;
//			}
//		System.out.println("Enter balance amount: ");
//		double balance=sc.nextDouble();
//		c.setBalance(balance);
//		long accNo=1010101010l+phoneNo;
//		c.setAccNo(accNo);
//		if(serviceC.createCustomer(c)==true) {
//			System.out.println("Account successfully created");
//		}
//		System.out.println("Generated account number: "+accNo);
//		break;
//	case 2:
//		System.out.println("Enter the account number of customer: ");
//		long accNum=sc.nextLong();
//		serviceC.getAccountDetails(accNum);
//		break;
//	case 3:
//		System.out.println("Enter account number to be deposited in: ");
//		long accnotemp=sc.nextLong();
//		System.out.println("Enter deposit amount: ");
//		double balance1=sc.nextDouble();
//		serviceC.deposit(accnotemp,balance1);
//		System.out.println(balance1+ " Deposited");
//		break;
//	case 4:
//		System.out.println("Enter account number to be withdrawn from: ");
//		long accnotemp3=sc.nextLong();
//		System.out.println("Enter amount to be withdrawn: ");
//		double balance2=sc.nextDouble();
//		serviceC.withdraw(accnotemp3,balance2);
//		System.out.println(balance2+ " withdrawn");
//		break;
//	case 5:
//		System.out.println("Enter account in which amount is to be transferred: ");
//		long accnotemp2=sc.nextLong();
//		System.out.println("Enter account to be transferred from: ");
//		long accnotemp4=sc.nextLong();
//		System.out.println("Enter amount to be transferred: ");
//		double balance3=sc.nextDouble();
//		serviceC.transfer(accnotemp2,accnotemp4,balance3);
//		System.out.println(balance3+" transferred to "+accnotemp2);
//		break;
//	case 6:
//		serviceC.printTransaction();
//		break;
//	case 7:
//		System.out.println("Exiting....");
//		System.exit(0);
//	}
//	System.out.println("do you want to continue (y/n):");
//	choice=sc.next().charAt(0);
//	}while(choice != 'n');
//	sc.close();
//	}
//	
//}
