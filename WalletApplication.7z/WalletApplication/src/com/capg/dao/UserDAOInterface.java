package com.capg.dao;

import com.capg.Model.User;

public interface UserDAOInterface {
	void getAccDetails(long accNumber);

	void depositMoney(long accnotemp, double balance1);

	void withdrawMoney(long accnotemp3,double balance2);

	void printTransactions();

	boolean createNewUser(User u);

	void transferMoney(long accnotemp2, long accnotemp4, double balance3);
}
