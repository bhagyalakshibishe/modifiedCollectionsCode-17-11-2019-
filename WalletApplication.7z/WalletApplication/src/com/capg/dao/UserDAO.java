package com.capg.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.capg.Model.User;

public class UserDAO implements UserDAOInterface {
	static User u1=new User();
	static Map<Long,User> users=new HashMap<Long,User>();
	ArrayList<String> mylist = new ArrayList<String>();
	@Override
	public void getAccDetails(long accNumber) {
		// TODO Auto-generated method stub
		
		if(users.containsKey(accNumber)) {
			Set<Entry<Long,User>> set=users.entrySet();     
			Iterator<Entry<Long,User>> itr=set.iterator();
			while(itr.hasNext()) {
				Map.Entry<Long, User> entry=(Map.Entry<Long, User>) itr.next();
				if(entry.getKey().equals(accNumber)) {
					User c=entry.getValue();
					System.out.println("Account Number: "+c.getAccNumber()+"\n Name: "+c.getName()+"\n phone number: "+c.getPhoneNumber()+"\n Balance amount: "+c.getBalance());
				}
			}
		}
	}

	@Override
	public void depositMoney(long accnotemp, double balance1) {
		// TODO Auto-generated method stub
		Set fnd=users.entrySet();
		Iterator it=fnd.iterator();
		double balanceD=0d;
		while(it.hasNext()) {
			Map.Entry<Long, User>entry=(Map.Entry<Long, User>)it.next();
			if(entry.getKey()==accnotemp) {
				balanceD=entry.getValue().getBalance()+balance1;
				entry.getValue().setBalance(balanceD);
				
			}
		}
		mylist.add(balance1 + " Deposited to "+accnotemp);
		
		
	}

	@Override
	public void withdrawMoney(long accnotemp3, double balance2) {
		// TODO Auto-generated method stub
		Set fnd=users.entrySet();
		Iterator it=fnd.iterator();
		double balanceW=0d;
		while(it.hasNext()) {
			Map.Entry<Long, User>entry=(Map.Entry<Long, User>)it.next();
			if(entry.getKey()==accnotemp3) {
				balanceW=entry.getValue().getBalance()-balance2;
				entry.getValue().setBalance(balanceW);
			}
		}
		mylist.add(balance2 + " Withdrawn from "+accnotemp3);
		
	}

	@Override
	public void printTransactions() {
		// TODO Auto-generated method stub
		for (String string : mylist) {
			System.out.println(string);
		}
	}

	@Override
	public boolean createNewUser(User user) {
		// TODO Auto-generated method stub
		u1=user;
		users.put(u1.getAccNumber(), user);
		return true;
	}

	@Override
	public void transferMoney(long accnotemp2, long accnotemp4, double balance3) {
		// TODO Auto-generated method stub
		Set fnd=users.entrySet();
		Iterator it=fnd.iterator();
		double balanceT1=0d;
		double balanceT2=0d;
		while(it.hasNext()) {
			Map.Entry<Long, User>entry=(Map.Entry<Long, User>)it.next();
			if(entry.getKey()==accnotemp2) {//acctemp2 is account to be credited to
				balanceT1=entry.getValue().getBalance()+balance3;
				entry.getValue().setBalance(balanceT1);
			}
			if(entry.getKey()==accnotemp4) {//acctemp4 is account to be credited from
				balanceT2=entry.getValue().getBalance()-balance3;
				entry.getValue().setBalance(balanceT2);
		}
	}
		mylist.add(balance3 + " Transferred from "+accnotemp4+" to "+accnotemp2);
	}

}
